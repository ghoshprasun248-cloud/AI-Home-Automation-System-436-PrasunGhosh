# AI Home Automation System
Full project with FastAPI, AI scheduler, WebSockets.
